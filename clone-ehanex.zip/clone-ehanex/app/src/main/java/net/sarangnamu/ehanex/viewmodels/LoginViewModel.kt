package net.sarangnamu.ehanex.viewmodels

import android.app.Application
import androidx.databinding.ObservableField
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import org.slf4j.LoggerFactory

/**
 * Created by <a href="mailto:aucd29@hanwha.com">Burke Choi</a> on 2018. 11. 14. <p/>
 */

class LoginViewModel(application: Application) : AndroidViewModel(application) {
    companion object {
        private val mLog = LoggerFactory.getLogger(LoginViewModel::class.java)
    }

    val userid = ObservableField<String>()
    val userpw = ObservableField<String>()
    val rememberId = MutableLiveData<Boolean>()
    val rememberPw = MutableLiveData<Boolean>()

    fun login() {
        if (mLog.isDebugEnabled) {
            mLog.debug("LOGIN")
        }
    }

    fun findUserName() {
        if (mLog.isDebugEnabled) {
            mLog.debug("FIND USER NAME")
        }
    }

    fun findUserPassword() {
        if (mLog.isDebugEnabled) {
            mLog.debug("FIND PASSWORD")
        }
    }

    fun joinMember() {
        if (mLog.isDebugEnabled) {
            mLog.debug("JOIN MEMBER")
        }
    }
}
