package net.sarangnamu.ehanex.views

import net.sarangnamu.common.BaseRuleFragment
import net.sarangnamu.common.viewModel
import net.sarangnamu.ehanex.databinding.LoginFragmentBinding
import net.sarangnamu.ehanex.viewmodels.LoginViewModel

/**
 * Created by <a href="mailto:aucd29@hanwha.com">Burke Choi</a> on 2018. 11. 14. <p/>
 */

class LoginFragment : BaseRuleFragment<LoginFragmentBinding>() {
    override fun bindViewModel() {
        mBinding.model = viewmodel()
    }

    fun viewmodel() = viewModel(LoginViewModel::class.java)
}