package net.sarangnamu.ehanex.viewmodels

import android.app.Application
import androidx.lifecycle.AndroidViewModel

/**
 * Created by <a href="mailto:aucd29@hanwha.com">Burke Choi</a> on 2018. 11. 14. <p/>
 */

class MainViewModel(application: Application) : AndroidViewModel(application) {

}