package net.sarangnamu.ehanex

import android.os.Bundle
import net.sarangnamu.common.BaseActivity
import net.sarangnamu.common.add
import net.sarangnamu.common.replace
import net.sarangnamu.ehanex.databinding.ActivityMainBinding
import net.sarangnamu.ehanex.views.LoginFragment
import net.sarangnamu.ehanex.views.MainFragment
import org.slf4j.LoggerFactory

class MainActivity : BaseActivity<ActivityMainBinding>() {
    companion object {
        private val mLog = LoggerFactory.getLogger(MainActivity::class.java)
    }

    override fun layoutId(): Int = R.layout.activity_main

//    private val mOnNavigationItemSelectedListener = BottomNavigationView.OnNavigationItemSelectedListener { item ->
//        when (item.itemId) {
//            R.id.navigation_home -> {
////                message.setText(R.string.title_home)
//                return@OnNavigationItemSelectedListener true
//            }
//            R.id.navigation_dashboard -> {
////                message.setText(R.string.title_dashboard)
//                return@OnNavigationItemSelectedListener true
//            }
//            R.id.navigation_notifications -> {
////                message.setText(R.string.title_notifications)
//                return@OnNavigationItemSelectedListener true
//            }
//        }
//        false
//    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        supportFragmentManager.run {
            if (savedInstanceState == null) {
                add(R.id.container, MainFragment::class.java)
            }

            // login 확인
            replace(R.id.container, LoginFragment::class.java)
        }
    }
}
